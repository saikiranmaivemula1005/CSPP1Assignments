# Write a python program to find the square root of the given number 
# using Bi-section method

def main():
	s = raw_input()
	#your code here

if __name__== "__main__":
	main()