# Write a python program to find the square root of the number 
# using Newton-Rapson method

def main():
	s = raw_input()
	#your code here

if __name__== "__main__":
	main()