# Write a python program to find if the given number is a perfect cube or not 
# using guess and check algorithm

def main():
	s = raw_input()
	#your code here

if __name__== "__main__":
	main()